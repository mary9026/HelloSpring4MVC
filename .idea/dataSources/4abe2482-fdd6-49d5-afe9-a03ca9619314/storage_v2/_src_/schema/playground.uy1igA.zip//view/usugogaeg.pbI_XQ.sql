create definer = playground@`%` view 우수고객 as
select `playground`.`sales_customers`.`cusid`   AS `cusid`,
       `playground`.`sales_customers`.`cusname` AS `cusname`,
       `playground`.`sales_customers`.`age`     AS `age`
from `playground`.`sales_customers`
where `playground`.`sales_customers`.`grade` = 'VIP';

