create definer = playground@`%` view 판매데이터 as
select `o`.`cusid`    AS `cusid`,
       `p`.`prodno`   AS `prodno`,
       `p`.`prdname`  AS `prdname`,
       `p`.`stock`    AS `stock`,
       `p`.`price`    AS `price`,
       `p`.`prdmaker` AS `prdmaker`,
       `o`.`ordno`    AS `ordno`,
       `o`.`qty`      AS `qty`,
       `o`.`addr`     AS `addr`,
       `o`.`orddate`  AS `orddate`,
       `c`.`cusname`  AS `cusname`,
       `c`.`age`      AS `age`,
       `c`.`grade`    AS `grade`,
       `c`.`job`      AS `job`,
       `c`.`bonus`    AS `bonus`
from ((`playground`.`sales_products` `p` join `playground`.`sales_orders` `o` on (`p`.`prodno` = `o`.`prodno`))
         join `playground`.`sales_customers` `c` on (`o`.`cusid` = `c`.`cusid`));

